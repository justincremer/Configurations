#Continues after core components are installed
# This can be removed later once this just works in Windows 10 2004
Invoke-WebRequest -Uri "https://wslstorestorage.blob.core.windows.net/wslblob/wsl_update_x64.msi" -OutFile "wsl_update_x64.msi"
msiexec.exe /I .\wsl_update_x64.msi /quiet
Remove-Item .\wsl_update_x64.msi
# End of remove later
wsl --set-default-version 2
choco install 7zip.install -y
choco install powershell-core -y --install-arguments='"ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1 REGISTER_MANIFEST=1 ENABLE_PSREMOTING=1"' --packageparameters '"/CleanUpPath"'
choco install wget -y
choco install -y azcopy
choco install azure-cli -y
choco install openssl.light -y
choco install filezilla -y
choco install sysinternals -y
choco install dotpeek -y
choco install linqpad -y
choco install fiddler -y
choco install foxitreader -y
choco install git -y
choco install gitkraken -y
choco install nodejs-lts -y
choco install nvm -y
choco install yarn -y
choco install cascadiacode -y
choco install cascadiacodepl -y
choco install googlechrome -y
choco install firefox -y
choco install microsoft-edge -y
choco install microsoft-edge-insider-dev -y
choco install dotnetcore-sdk -y
choco install vscode -y
choco install androidstudio -y
choco install azure-data-studio -y
choco install microsoftazurestorageexplorer -y
choco install postman -y
choco install gitkraken -y
choco install docker-desktop -y
choco install visualstudio2019enterprise -y
choco install visualstudio2019-workload-azure -y
choco install visualstudio2019-workload-data -y
choco install visualstudio2019-workload-datascience -y
choco install visualstudio2019-workload-manageddesktop -y
choco install visualstudio2019-workload-netcoretools -y
choco install visualstudio2019-workload-netcrossplat -y
choco install visualstudio2019-workload-netweb -y
choco install visualstudio2019-workload-universal -y
choco install kubernetes-helm -y
choco install nuget.commandline -y
choco install chocolateygui -y
choco install rufus -y
choco install azurepowershell -y
choco install powertoys -y
choco install jq -y
choco install ngrok -y
choco install wixtoolset -y
choco install poshgit -y
choco install oh-my-posh -y
choco install get-childitemcolor -y
choco install sass -y
Install-Module -Name AzureAD -Confirm:$False
Install-Module MSOnline -Confirm:$False
Install-Module -Name MicrosoftTeams -Confirm:$False
Install-Module -Name ExchangeOnlineManagement -Confirm:$False
Install-Module -Name Microsoft.Online.SharePoint.PowerShell -Confirm:$False
Install-Module -Name PSReadLine -AllowPrerelease -Scope CurrentUser -Force -SkipPublisherCheck -Confirm:$False
npm install -g rimraf npm-check-updates yo rn-nodeify
Install-Module -Name PSKubectlCompletion -Confirm:$False
Import-Module -Name PSKubectlCompletion
Register-KubectlCompletion
az aks install-cli

wsl sudo apt-get update && sudo apt-get install -yqq daemonize dbus-user-session fontconfig
wsl sudo daemonize /usr/bin/unshare --fork --pid --mount-proc /lib/systemd/systemd --system-unit=basic.target
wsl exec sudo nsenter -t $(pidof systemd) -a su - $LOGNAME

Write-Host "Plugins will be installed automatically for each project in VS Code for you. You should choose your WSL Distro (ubuntu) from the store and install Windows Terminal from the Store As Well.";
Write-Host "Suggest updating VS Code, Terminal and Visual Studio to use Cascadia Code Font and turn on legitures.";
Write-Host "In separate powershell windows for both default powershell and powershell core type notepad $PROFILE and paste in the contents of the PowershellCmdTemplate.ps1.";
Read-Host -Prompt "Setup is done, restart is needed, press [ENTER] to restart computer."
Restart-Computer